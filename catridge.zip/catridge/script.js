document.querySelector('.cart-btn').addEventListener('click', function() {
    alert('Item telah ditambahkan ke keranjang!');
});
